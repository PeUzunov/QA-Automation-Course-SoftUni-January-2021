using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Windows;
using OpenQA.Selenium.Interactions;
using System;
using System.IO;
using System.Threading;

namespace NUnitTestProject_7Zip_Appium
{
    public class Tests7Zip
    {
        private const string AppiumServerUrl = "http://[::1]:4723/wd/hub";
        private const string AppForTesting = @"C:\Program Files\7-Zip\7zFM.exe";
        private const string Path7Zip = @"C:\Program Files\7-Zip\";
        private WindowsDriver<WindowsElement> driver;
        private WindowsDriver<WindowsElement> driverDesktop;
        private string workDir;

        [OneTimeSetUp]
        public void Setup()
        {
            //creating Appiun session
            var appiumOptions = new AppiumOptions() { PlatformName = "Windows" };
            appiumOptions.AddAdditionalCapability("app", AppForTesting);
            driver = new WindowsDriver<WindowsElement>(new Uri(AppiumServerUrl), appiumOptions);

            //creating Appiun session for the Root app
            var appiumOptionsDesktop = new AppiumOptions() { PlatformName = "Windows" };
            appiumOptionsDesktop.AddAdditionalCapability("app", "Root");
            driverDesktop = new WindowsDriver<WindowsElement>(new Uri(AppiumServerUrl), appiumOptionsDesktop);

            //creating 7 zip temp folder
            workDir = Directory.GetCurrentDirectory() + @"\tempDir";
            if (Directory.Exists(workDir))         
                Directory.Delete(workDir, true);
                Directory.CreateDirectory(workDir);          
        }

        [Test]
        public void Test7Zip()
        {
            //Main 7Zip Window
            var textBoxLocation = driver.FindElementByXPath("/Window/Pane/Pane/ComboBox/Edit");
            textBoxLocation.SendKeys(Path7Zip);
            textBoxLocation.SendKeys(Keys.Enter);

            var listBoxFiles = driver.FindElementByXPath("/Window/Pane/List[@ClassName=\"SysListView32\"]");
            listBoxFiles.SendKeys(Keys.Control + "a");

            var buttonAdd = driver.FindElementByXPath("/Window/ToolBar[@ClassName=\"ToolbarWindow32\"]/Button[@Name=\"Add\"]");
            buttonAdd.Click();

            Thread.Sleep(1000);
			
            //Create the Archive
            var windowCreateArchive = driverDesktop.FindElementByName("Add to Archive");
                //this is working 1 in 5 times - driverDesktop.FindElementByXPath("/Pane[@ClassName=\"#32769\"][@Name=\"Desktop 1\"]/Window[@ClassName=\"#32770\"][@Name=\"Add to Archive\"]");

            var texBoxArchiveName = windowCreateArchive.FindElementByXPath("/Window/ComboBox/Edit[@ClassName=\"Edit\"][@Name=\"Archive:\"]");
            string archiveFileName = workDir + @"\" + "archive.7z";
            texBoxArchiveName.SendKeys(archiveFileName);

            var textBoxArchiveFormat = windowCreateArchive.FindElementByXPath("/Window/ComboBox[@ClassName=\"ComboBox\"][@Name=\"Archive format:\"]");
            textBoxArchiveFormat.SendKeys("7z");

            var textBoxCompressionLevel = windowCreateArchive.FindElementByXPath("/Window/ComboBox[@ClassName=\"ComboBox\"][@Name=\"Compression level:\"]");
            textBoxCompressionLevel.SendKeys("Ultra");

            var textBoxCompressionMethod = windowCreateArchive.FindElementByXPath("/Window/ComboBox[@ClassName=\"ComboBox\"][@Name=\"Compression method:\"]");
            textBoxCompressionMethod.SendKeys(Keys.Home);

            var textBoxDictionarySize = windowCreateArchive.FindElementByXPath("/Window/ComboBox[@ClassName=\"ComboBox\"][@Name=\"Dictionary size:\"]");
            textBoxDictionarySize.SendKeys(Keys.End);

            var textBoxWordSize = windowCreateArchive.FindElementByXPath("/Window/ComboBox[@ClassName=\"ComboBox\"][@Name=\"Word size:\"]");
            textBoxWordSize.SendKeys(Keys.End);

            var buttonOKAddToArchive = windowCreateArchive.FindElementByXPath("/Window/Button[@ClassName=\"Button\"][@Name=\"OK\"]");
            buttonOKAddToArchive.Click();

			Thread.Sleep(1000);
			
            //Extract the archive
            textBoxLocation.SendKeys(archiveFileName + Keys.Enter);

            var buttonExtract = driver.FindElementByXPath("/Window/ToolBar[@ClassName=\"ToolbarWindow32\"]/Button[@Name=\"Extract\"]");
            buttonExtract.Click();

            var buttonOKExtract = driver.FindElementByName("OK");
            buttonOKExtract.Click();

            Thread.Sleep(1000);
			
            //Assert files are the same
            foreach (string fileOriginal in Directory.EnumerateFiles(Path7Zip, "*.*", SearchOption.AllDirectories))
            {
                var fileNameOnly = fileOriginal.Replace(Path7Zip, "");
                var fileCopy = workDir + @"\" + fileNameOnly;
                FileAssert.AreEqual(fileCopy, fileOriginal);
            }


            //FileAssert.AreEqual(workDir + @"\7zFM.exe", Path7Zip + @"\7zFM.exe");

        }

        [OneTimeTearDown]
        public void TearDown()
        {
            driver.Quit();
			driverDesktop.Quit();
        }
    }
}