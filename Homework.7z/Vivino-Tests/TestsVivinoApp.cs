using NUnit.Framework;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.Enums;
using OpenQA.Selenium.Appium.Service;
using System;
using System.Globalization;
using System.Threading;

namespace Vivino_Tests
{
    public class TestsVivinoApp
    {
        private const string AppiumServerUrl = "http://[::1]:4723/wd/hub";
        private const string VivinoLoginEmail = "pesho@abv.bg";
        private const string VivinoLoginPassword = "parola1parola1";
        private const string VivinoAppPackage = "vivino.web.app";
        private const string VivinoAppStartupActivity = "com.sphinx_solution.activities.SplashActivity";
        private AndroidDriver<AndroidElement> driver;

        [OneTimeSetUp]
        public void SetupRemoteServer()
        {
            //use this in case parsing is still not working
            //Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.InvariantCulture;

            var appiumOptions = new AppiumOptions() { PlatformName = "Android" };
            //appiumOptions.AddAdditionalCapability("app", @"C:\QA-Automation\9.EXERCISE-APPIUM-FOR-DESKTOP-AND-MOBILE-TESTING\vivino_8.18.11-8181203.apk");
            appiumOptions.AddAdditionalCapability("appPackage", VivinoAppPackage);
            appiumOptions.AddAdditionalCapability("appActivity", VivinoAppStartupActivity);

            driver = new AndroidDriver<AndroidElement>(new Uri(AppiumServerUrl), appiumOptions);

            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(60);
        }

        [Test]
        public void Test()
        {   
            //login in the Vivino app
            var linkLogin = driver.FindElementById("vivino.web.app:id/txthaveaccount");
            linkLogin.Click();

            var textBoxLoginEmail = driver.FindElementById("vivino.web.app:id/edtEmail");
            textBoxLoginEmail.SendKeys(VivinoLoginEmail);
            var textBoxLoginPassword = driver.FindElementById("vivino.web.app:id/edtPassword");
            textBoxLoginPassword.SendKeys(VivinoLoginPassword);
            var buttonLogin = driver.FindElementById("vivino.web.app:id/action_signin");
            buttonLogin.Click();

            //search for the specific wine "Katarzyna Reserve Red 2006"
            var buttonHeaderSearch = driver.FindElementById("vivino.web.app:id/wine_explorer_tab");
            buttonHeaderSearch.Click();

            var boxSearch = driver.FindElementById("vivino.web.app:id/search_vivino");
            boxSearch.Click();

            var texBoxSearch = driver.FindElementById("vivino.web.app:id/editText_input");
            texBoxSearch.SendKeys("Katarzyna Reserve Red 2006");


            //click on first search result
            var listSearchResults = driver.FindElementById("vivino.web.app:id/listviewWineListActivity");
            var firstResult = listSearchResults.FindElementByClassName("android.widget.FrameLayout");
            firstResult.Click();

            //check selected wine details
            var elementWineName = driver.FindElementById("vivino.web.app:id/wine_name");
            Assert.AreEqual("Reserve Red 2006", elementWineName.Text);

            var elementRaiting = driver.FindElementById("vivino.web.app:id/rating");
            var raitingText = elementRaiting.Text;
            //parsing the string to number using CultureInfo. Otherwize the . and , are not able to be parsed propery
            double rating = double.Parse(raitingText, CultureInfo.InvariantCulture);
            //decimal rating = decimal.Parse(raitingText, CultureInfo.InvariantCulture);
            Assert.IsTrue(rating >= 1.00 && rating <= 5.00);

            var tabsSummary = driver.FindElementById("vivino.web.app:id/tabs");
            var tabHighlights = driver.FindElementByXPath("//android.widget.TextView[1]");
            //cant find tabFacts by using the showrt XPath for batHighlights
            var tabFacts = driver.FindElementByXPath("//android.widget.FrameLayout[2]/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.HorizontalScrollView/android.widget.LinearLayout/android.widget.TextView[2]");
            tabHighlights.Click();
            var highlightsDescription = driver.FindElementByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))" +
                ".scrollIntoView(new UiSelector().resourceIdMatches(\"vivino.web.app:id/highlight_description\"))");       
            Assert.AreEqual("Among top 1% of all wines in the world", highlightsDescription.Text);

            tabFacts.Click();
            var factTitle = driver.FindElementById("vivino.web.app:id/wine_fact_title");
            Assert.AreEqual("Grapes", factTitle.Text);
            var factText = driver.FindElementById("vivino.web.app:id/wine_fact_text");
            Assert.AreEqual("Cabernet Sauvignon,Merlot", factText.Text);
        }

        [OneTimeTearDown]
        public void ShutDown()
        {
            driver.Quit();
        }
    }
}