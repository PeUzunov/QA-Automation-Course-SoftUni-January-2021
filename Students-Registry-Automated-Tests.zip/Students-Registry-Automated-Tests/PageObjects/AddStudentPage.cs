﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace Students_Registry_Automated_Tests.PageObjects
{
    public class AddStudentPage : BasePage
    {
        public AddStudentPage(IWebDriver driver) : base(driver)
        {

        }
        public override string PageUrl => "https://mvc-app-node-express.nakov.repl.co/add-student";

        public IWebElement FieldName => driver.FindElement(By.Id("name"));
        public IWebElement FieldEmail => driver.FindElement(By.Id("email"));
        public IWebElement ButtonSubmit => driver.FindElement(By.CssSelector("body > form > button"));
        public IWebElement ErrorMessageAddStudent => driver.FindElement(By.CssSelector("body > div"));

        public void AddStudent(string name, string email)
        {
           this.FieldName.SendKeys(name);
           this.FieldEmail.SendKeys(email);
            this.ButtonSubmit.Click();    
        }

    }
}
