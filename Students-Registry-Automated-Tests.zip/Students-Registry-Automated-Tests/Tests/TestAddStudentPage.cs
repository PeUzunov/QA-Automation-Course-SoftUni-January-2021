using NUnit.Framework;
using Students_Registry_Automated_Tests.PageObjects;
using System;
using System.Linq;

namespace Students_Registry_Automated_Tests.Tests
{
    public class TestAddStudentPage : BaseTest
    {
        [Test]
        public void Test_AddStudentsPage_Content()
        {
            var page = new AddStudentPage(driver);
            page.Open();

            Assert.AreEqual("Add Student", page.GetPageTitle());
            Assert.AreEqual("Register New Student", page.GetPageHeadingText());
            Assert.IsEmpty(page.FieldName.Text);
            Assert.IsEmpty(page.FieldEmail.Text);
            Assert.AreEqual("Add", page.ButtonSubmit.Text);
        }

        [Test]
        public void Test_AddStudentPage_Links()
        {
            var addStudentPage = new StudentsPage(driver);

            addStudentPage.Open();
            addStudentPage.LinkHomePage.Click();
            Assert.IsTrue(new HomePage(driver).IsOpen());

            addStudentPage.Open();
            addStudentPage.LinkAddStudentPage.Click();
            Assert.IsTrue(new AddStudentPage(driver).IsOpen());

            addStudentPage.Open();
            addStudentPage.LinkViewStudentsPage.Click();
            Assert.IsTrue(new StudentsPage(driver).IsOpen());
        }

        [Test]
        public void Test_AddStudentsPage_AddValidStudent()
        {
            var pageAddStudent = new AddStudentPage(driver);
            pageAddStudent.Open();
            string name = "Test Name Field" + DateTime.Now.Ticks;
            string email = "TestEmail" + DateTime.Now.Ticks + "@email.com";
            pageAddStudent.AddStudent(name, email);

            var pageStudents = new StudentsPage(driver);
            Assert.IsTrue(pageStudents.IsOpen());

            var students = pageStudents.GetRegisteredStudents();
            string newStudent = name + " (" + email + ")";

            Assert.Contains(newStudent, students);
        }

        [Test]
        public void Test_AddStudentsPage_AddInvalidStudent()
        {
            var pageAddStudent = new AddStudentPage(driver);
            pageAddStudent.Open();
            string name = "";
            string email = "TestEmail" + DateTime.Now.Ticks + "@email.com";
            pageAddStudent.AddStudent(name, email);

            Assert.IsTrue(pageAddStudent.IsOpen());
            Assert.IsTrue(pageAddStudent.ErrorMessageAddStudent.Text.Contains("Cannot add student. Name and email fields are required!"));
        }
    }
}