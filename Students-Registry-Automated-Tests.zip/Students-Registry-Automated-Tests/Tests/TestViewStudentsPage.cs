using NUnit.Framework;
using Students_Registry_Automated_Tests.PageObjects;

namespace Students_Registry_Automated_Tests.Tests
{
    public class TestViewStudentsPage : BaseTest
    {
        [Test]
        public void Test_StudentsPage_Content()
        {
            var page = new StudentsPage(driver);
            page.Open();

            Assert.AreEqual("Students", page.GetPageTitle());
            Assert.AreEqual("Registered Students", page.GetPageHeadingText());

            var students = page.GetRegisteredStudents();
            foreach (string st in students)
            {
                Assert.IsTrue(st.IndexOf("(") > 0);
                Assert.IsTrue(st.IndexOf(")") == st.Length-1);
            }
        }

        [Test]
        public void Test_StudentsPage_Links()
        {
            var studentsPage = new StudentsPage(driver);

            studentsPage.Open();
            studentsPage.LinkHomePage.Click();
            Assert.IsTrue(new HomePage(driver).IsOpen());

            studentsPage.Open();
            studentsPage.LinkAddStudentPage.Click();
            Assert.IsTrue(new AddStudentPage(driver).IsOpen());

            studentsPage.Open();
            studentsPage.LinkViewStudentsPage.Click();
            Assert.IsTrue(new StudentsPage(driver).IsOpen());

        }
    }
}