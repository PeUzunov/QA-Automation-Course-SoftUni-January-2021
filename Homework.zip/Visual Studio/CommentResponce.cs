﻿namespace API_Tests_GitHub
{
    public class CommentResponce
    {
        public long id { get; set; }
        public long number { get; set; }
        public string body { get; set; }

        
    }
}