using NUnit.Framework;
using RestSharp;
using RestSharp.Authenticators;
using RestSharp.Serialization.Json;
using System;
using System.Collections.Generic;
using System.Net;

namespace API_Tests_GitHub
{
    public class Tests
    {
        const string GitHubAPIUserName = "put_your_username_here";
        const string GitHubAPIPassword = "put_your_password_here";

        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test_GitHubAPI_GetIssuesByRepo()
        {

            var client = new RestClient("https://api.github.com/repos/testnakov/test-nakov-repo/issues");
            client.Timeout = 3000;
            var request = new RestRequest(Method.GET);
            var responce = client.Execute(request);

            Assert.AreEqual(HttpStatusCode.OK, responce.StatusCode);

            Assert.IsTrue(responce.ContentType.StartsWith("application/json"));

            var issues = new JsonDeserializer().Deserialize<List<IssueResponce>>(responce);

            Assert.Pass();
        }

        [Test]
        public void Test_GitHubAPI_CreateNewIssue()
        {
            var client = new RestClient("https://api.github.com/repos/testnakov/test-nakov-repo/issues");
            client.Timeout = 3000;
            var request = new RestRequest(Method.POST);
            client.Authenticator = new HttpBasicAuthenticator(GitHubAPIUserName, GitHubAPIPassword);
            request.AddHeader("Content-Type", "application/json");
            request.AddJsonBody(new {
                title = "Message Title C# test",
                body = "MEssage body C# test",
                labels = new string[] {"bug", "importance:high", "type:UI"}
            });
            var response = client.Execute(request);

            Assert.AreEqual(HttpStatusCode.Created, response.StatusCode);

            Assert.IsTrue(response.ContentType.StartsWith("application/json"));

            var issue = new JsonDeserializer().Deserialize<IssueResponce>(response);

            Assert.IsTrue(issue.id > 0);
            Assert.IsTrue(issue.number > 0);
            Assert.IsTrue(!String.IsNullOrEmpty(issue.title));
            Assert.IsTrue(!String.IsNullOrEmpty(issue.body));
        }

        [Test]
        public void Test_GitHubAPI_CreateNewIssue_Unauthorized()
        {

            var client = new RestClient("https://api.github.com/repos/testnakov/test-nakov-repo/issues/1285");
            client.Timeout = 3000;
            var request = new RestRequest(Method.POST);
            // client.Authenticator = new HttpBasicAuthenticator(GitHubAPIUserName, GitHubAPIPassword);
            request.AddHeader("Content-Type", "application/json");
            request.AddJsonBody(new
            {
                title = "Message Title C# test",
                body = "MEssage body C# test",
                labels = new string[] { "bug", "importance:high", "type:UI" }
            });
            var response = client.Execute(request);

            Assert.AreEqual(HttpStatusCode.Unauthorized, response.StatusCode);
        }

        [Test]
        public void Test_GitHubAPI_CreateNewIssue_MissingTitle()
        {

            var client = new RestClient("https://api.github.com/repos/testnakov/test-nakov-repo/issues");
            client.Timeout = 3000;
            var request = new RestRequest(Method.POST);
            client.Authenticator = new HttpBasicAuthenticator(GitHubAPIUserName, GitHubAPIPassword);
            request.AddHeader("Content-Type", "application/json");
            request.AddJsonBody(new
            {
                body = "MEssage body C# test",
                labels = new string[] { "bug", "importance:high", "type:UI" }
            });
            var response = client.Execute(request);

            Assert.AreEqual(HttpStatusCode.UnprocessableEntity, response.StatusCode);
        }

        [Test]
        public void Test_GitHubAPI_DeleteComment()
        {
            //Create new comment for issue 9
            var clientCreate = new RestClient("https://api.github.com/repos/testnakov/test-nakov-repo/issues/9/comments");
            clientCreate.Timeout = 3000;
            var requestCreate = new RestRequest(Method.POST);
            clientCreate.Authenticator = new HttpBasicAuthenticator(GitHubAPIUserName, GitHubAPIPassword);
            requestCreate.AddHeader("Content-Type", "application/json");
            requestCreate.AddJsonBody(new
            {
                body = "Message body C# test"
            });

            var responseCreate = clientCreate.Execute(requestCreate);

            var comment = new JsonDeserializer().Deserialize<CommentResponce>(responseCreate);

            var commentNumber = comment.id;

            Assert.AreEqual(HttpStatusCode.Created, responseCreate.StatusCode);

            //Delete comment
            var clietnDelete = new RestClient("https://api.github.com/repos/testnakov/test-nakov-repo/issues/comments/" + commentNumber);
            clietnDelete.Timeout = 3000;
            var requestDelete = new RestRequest(Method.DELETE);
            clietnDelete.Authenticator = new HttpBasicAuthenticator(GitHubAPIUserName, GitHubAPIPassword);

            var responseDelete = clietnDelete.Execute(requestDelete);

            Assert.AreEqual(HttpStatusCode.NoContent, responseDelete.StatusCode);

        }

        [Test]
        public void Test_GitHubAPI_EditExistingIssue()
        {
            //create new issue
            var clientCreateIssue = new RestClient("https://api.github.com/repos/testnakov/test-nakov-repo/issues");
            clientCreateIssue.Timeout = 3000;
            var requestCreateIssue = new RestRequest(Method.POST);
            clientCreateIssue.Authenticator = new HttpBasicAuthenticator(GitHubAPIUserName, GitHubAPIPassword);
            requestCreateIssue.AddHeader("Content-Type", "application/json");
            requestCreateIssue.AddJsonBody(new
            {
                title = "Message Title C# test",
                body = "MEssage body C# test",
                labels = new string[] { "bug", "importance:high", "type:UI" }
            });
            var responseCreateIssue = clientCreateIssue.Execute(requestCreateIssue);

            var newIssue = new JsonDeserializer().Deserialize<IssueResponce>(responseCreateIssue);

            var issueNumber = newIssue.number;

            //edit issue
            var client = new RestClient("https://api.github.com/repos/testnakov/test-nakov-repo/issues/" + issueNumber);
            client.Timeout = 3000;
            var request = new RestRequest(Method.PATCH);
            client.Authenticator = new HttpBasicAuthenticator(GitHubAPIUserName, GitHubAPIPassword);
            request.AddHeader("Content-Type", "application/json");
            request.AddJsonBody(new
            {
                title = "Message title created by Uzunov",
                body = "Message body created by Uzunov \n and later modified to test Status 200 OK"          
            });
            var response = client.Execute(request);

            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);

            Assert.IsTrue(response.ContentType.StartsWith("application/json"));

            var issue = new JsonDeserializer().Deserialize<CommentResponce>(response);

            Assert.IsTrue(issue.id > 0);
            Assert.IsTrue(issue.number > 0);
        }

        [Test]
        public void Test_GitHubAPI_EditExistingIssueWithInvalidIssueNumber()
        {
            var client = new RestClient("https://api.github.com/repos/testnakov/test-nakov-repo/issues/1285123456789");
            client.Timeout = 3000;
            var request = new RestRequest(Method.PATCH);
            client.Authenticator = new HttpBasicAuthenticator(GitHubAPIUserName, GitHubAPIPassword);
            request.AddHeader("Content-Type", "application/json");
            request.AddJsonBody(new
            {
                title = "Message title created by Uzunov",
                body = "Message body created by Uzunov \n and later modified to test Status 200 OK"
            });
            var response = client.Execute(request);

            Assert.AreEqual(HttpStatusCode.NotFound, response.StatusCode);
        }

        [Test]
        public void Test_GitHubAPI_EditExistingIssueWithoutAuthHeader()
        {
            var client = new RestClient("https://api.github.com/repos/testnakov/test-nakov-repo/issues/1285");
            client.Timeout = 3000;
            var request = new RestRequest(Method.PATCH);
            // client.Authenticator = new HttpBasicAuthenticator(GitHubAPIUserName, GitHubAPIPassword);
            request.AddHeader("Content-Type", "application/json");
            request.AddJsonBody(new
            {
                title = "Message title created by Uzunov",
                body = "Message body created by Uzunov \n and later modified to test Status 200 OK"
            });
            var response = client.Execute(request);

            Assert.AreEqual(HttpStatusCode.Unauthorized, response.StatusCode);
        }
    }
}