﻿namespace ContactBookAPITests
{
    internal class UrlResponceCreateNewContact
    {        
        public string msg { get; set; }
        public UrlResponce contact { get; set; }
    }
}
