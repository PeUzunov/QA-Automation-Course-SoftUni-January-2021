using NUnit.Framework;
using RestSharp;
using RestSharp.Serialization.Json;
using System;
using System.Collections.Generic;
using System.Net;

namespace ContactBookAPITests
{
    public class ContactBookAPITests
    {
        private const string ApiBaseUrl = "https://contactbook.petaruzunov.repl.co/api/";
        private RestClient client;

        [OneTimeSetUp]
        public void SetUp()
        {
            this.client = new RestClient(ApiBaseUrl);
            this.client.Timeout = 3000;
        }

        [Test]
        public void Test_ShortUrlAPI_GetAllContacts_AssertFirstIsSteveJobs()
        {
            //Arrange
            var request = new RestRequest("/contacts", Method.GET);

            //Act
            var responce = client.Execute(request);
            var contactList = new JsonDeserializer().Deserialize<List<UrlResponce>>(responce);
            var firstContactFirstName = contactList[0].firstName;
            var firstContactLastName = contactList[0].lastName;

            //Assert
            Assert.AreEqual(HttpStatusCode.OK, responce.StatusCode);
            Assert.IsTrue(contactList != null);
            Assert.AreEqual("Steve", firstContactFirstName);
            Assert.AreEqual("Jobs", firstContactLastName);
        }

        [Test]
        public void Test_ShortUrlAPI_GetContactByKeyword()
        {
            //Arrange
            var keyword = "albert";
            var request = new RestRequest("/contacts/search/" + keyword, Method.GET);

            //Act
            var responce = client.Execute(request);
            var contactList = new JsonDeserializer().Deserialize<List<UrlResponce>>(responce);
            var firstContactFirstName = contactList[0].firstName;
            var firstContactLastName = contactList[0].lastName;

            //Assert
            Assert.AreEqual(HttpStatusCode.OK, responce.StatusCode);
            Assert.IsTrue(contactList != null);
            Assert.AreEqual("Albert", firstContactFirstName);
            Assert.AreEqual("Einstein", firstContactLastName);
        }

        [Test]
        public void Test_ShortUrlAPI_GetContactByKeyword_MissingKeyword()
        {
            //Arrange
            var keyword = DateTime.Now.Ticks;
            var request = new RestRequest("/contacts/search/" + keyword, Method.GET);

            //Act
            var responce = client.Execute(request);
            var contactList = new JsonDeserializer().Deserialize<List<UrlResponce>>(responce);

            //Assert
            Assert.AreEqual(HttpStatusCode.OK, responce.StatusCode);
            Assert.IsEmpty(contactList);
        }

        [Test]
        public void Test_ShortUrlAPI_CreateNewContact()
        {
            //Arrange
            var request = new RestRequest("/contacts", Method.POST);
            var NewContactData = new
            {
                firstName = "Name" + DateTime.Now.Ticks,
                lastName = "LastName" + DateTime.Now.Ticks,
                email = "email@abv" + DateTime.Now.Ticks + ".bg",
                phone = "+123456789" + DateTime.Now.Ticks,
                comments = "comment goes here" + DateTime.Now.Ticks
            };

            //Act
            request.AddJsonBody(NewContactData);
            var responce = client.Execute(request);
            var newContactResponce = new JsonDeserializer().Deserialize<UrlResponceCreateNewContact>(responce);

            //Assert
            Assert.AreEqual(HttpStatusCode.Created, responce.StatusCode);
            Assert.AreEqual("Contact added.", newContactResponce.msg);
            Assert.AreEqual(NewContactData.firstName, newContactResponce.contact.firstName);
            Assert.AreEqual(NewContactData.lastName, newContactResponce.contact.lastName);
            Assert.AreEqual(NewContactData.email, newContactResponce.contact.email);
            Assert.AreEqual(NewContactData.phone, newContactResponce.contact.phone);
            Assert.AreEqual(NewContactData.comments, newContactResponce.contact.comments);
        }

        [Test]
        public void Test_ShortUrlAPI_CreateNewContact_InvalidData_EmptyFieldFirstName()
        {
            //Arrange
            var request = new RestRequest("/contacts", Method.POST);
            var NewContactData = new
            {
                firstName = "",
                lastName = "LastName" + DateTime.Now.Ticks,
                email = "email@abv" + DateTime.Now.Ticks + ".bg",
                phone = "+123456789" + DateTime.Now.Ticks,
                comments = "comment goes here" + DateTime.Now.Ticks
            };

            //Act
            request.AddJsonBody(NewContactData);
            var responce = client.Execute(request);
            var newContactResponce = new JsonDeserializer().Deserialize<UrlResponceErrMessage>(responce);


            //Assert
            Assert.AreEqual(HttpStatusCode.BadRequest, responce.StatusCode);
            Assert.AreEqual("First name cannot be empty!", newContactResponce.errMsg);
        }
    }
}