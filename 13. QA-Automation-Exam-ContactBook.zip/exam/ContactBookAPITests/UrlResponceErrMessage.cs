﻿namespace ContactBookAPITests
{
    internal class UrlResponceErrMessage
    {
        public string errMsg { get; set; }
    }
}