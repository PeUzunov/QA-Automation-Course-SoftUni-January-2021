using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;

namespace ContactBookUITests
{
    public class ContactBookUITests
    {
        ChromeDriver driver;

        [OneTimeSetUp]
        public void Setup()
        {
            driver = new ChromeDriver();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(3);
            driver.Navigate().GoToUrl("https://contactbook.petaruzunov.repl.co/");
        }

        [Test]
        public void Test_ContactsPage_ListAllContacts()
        {
            //Arrange
            var ContactsPageLink = driver.FindElementByCssSelector("body > aside > ul > li:nth-child(2) > a");

            //Act
            ContactsPageLink.Click();

            var contacts = driver.FindElements(By.CssSelector("body > main > div > a"));
            var firstContact = contacts[0].FindElements(By.CssSelector("tbody > tr > td"));
            var firstContactFirstName = firstContact[0].Text;
            var firstContactLastName = firstContact[1].Text;

            //Assert
            Assert.AreEqual("Steve Jobs", firstContactFirstName + " " + firstContactLastName);
            //Assert.AreEqual("Steve", firstContactFirstName);
            //Assert.AreEqual("Jobs", firstContactLastName);
        }

        [Test]
        public void Test_SearchContactsPage_SearchContactByKeyword()
        {
            //Arrange
            var SearchContactPageLink = driver.FindElementByCssSelector("body > aside > ul > li:nth-child(4) > a");
            SearchContactPageLink.Click();

            var keyword = "albert";

            //Act
            var fieldSearch = driver.FindElement(By.Id("keyword"));
            fieldSearch.Click();
            fieldSearch.SendKeys(keyword);

            var buttonSearch = driver.FindElement(By.Id("search"));
            buttonSearch.Click();

            var contacts = driver.FindElements(By.CssSelector("body > main > div.contacts-grid"));
            var firstContact = contacts[0].FindElements(By.CssSelector("tbody > tr > td")); 
            var firstContactFirstName = firstContact[0].Text;
            var firstContactLastName = firstContact[1].Text;

            //Assert
            Assert.AreEqual("Albert Einstein", firstContactFirstName + " " + firstContactLastName);
            //Assert.AreEqual("Albert", firstContactFirstName );
            //Assert.AreEqual("Einstein", firstContactLastName);
        }

        [Test]
        public void Test_SearchContactsPage_SearchContactByKeyword_InvalidKeyword()
        {

            //Arrange
            var SearchContactPageLink = driver.FindElementByCssSelector("body > aside > ul > li:nth-child(4) > a");
            SearchContactPageLink.Click();

            var keyword = "ivalid" + DateTime.Now.Ticks;

            //Act
            var fieldSearch = driver.FindElement(By.Id("keyword"));
            fieldSearch.SendKeys(keyword);

            var buttonSearch = driver.FindElement(By.Id("search"));
            buttonSearch.Click();

            var searchResult = driver.FindElement(By.Id("searchResult"));

            //Assert
            Assert.AreEqual("No contacts found.", searchResult.Text);
        }

        [Test]
        public void Test_CreateNewContactPage_CreateNewContact()
        {

            //Arrange
            var CreateContactPageLink = driver.FindElementByCssSelector("body > aside > ul > li:nth-child(3) > a");
            CreateContactPageLink.Click();

            var fieldFirstName = driver.FindElement(By.Id("firstName"));
            var fieldLastName = driver.FindElement(By.Id("lastName"));
            var fieldEmail = driver.FindElement(By.Id("email"));
            var fieldPhone = driver.FindElement(By.Id("phone"));
            var fieldComments = driver.FindElement(By.Id("comments"));

            var buttonCreate = driver.FindElement(By.Id("create"));

            var firstNameData = "Name" + DateTime.Now.Ticks;
            var lastNameData = "LastName" + DateTime.Now.Ticks;
            var emailData = "email@abv" + DateTime.Now.Ticks + ".bg";
            var phoneData = "+123456789" + DateTime.Now.Ticks;
            var commentsData = "comment goes here" + DateTime.Now.Ticks;

            //Act
            fieldFirstName.SendKeys(firstNameData);
            fieldLastName.SendKeys(lastNameData);
            fieldEmail.SendKeys(emailData);
            fieldPhone.SendKeys(phoneData);
            fieldComments.SendKeys(commentsData);
            buttonCreate.Click();

            var singleContactDetails = driver.FindElements(By.CssSelector("a > table"));

            var lastContact = singleContactDetails[singleContactDetails.Count - 1];
            var lastContactDetails = lastContact.FindElements(By.CssSelector("tr > td"));

            //Assert
            Assert.AreEqual(firstNameData, lastContactDetails[0].Text);
            Assert.AreEqual(lastNameData, lastContactDetails[1].Text);
            Assert.AreEqual(emailData, lastContactDetails[2].Text);
            Assert.AreEqual(phoneData, lastContactDetails[3].Text);
            Assert.AreEqual(commentsData, lastContactDetails[4].Text);
        }

        [Test]
        public void Test_CreateNewContactPage_CreateNewContact_InvalidData_EmptyFirstName()
        {

            //Arrange
            var CreateContactPageLink = driver.FindElementByXPath("/html/body/aside/ul/li[3]/a");
            CreateContactPageLink.Click();

            var fieldFirstName = driver.FindElement(By.Id("firstName"));
            var fieldLastName = driver.FindElement(By.Id("lastName"));
            var fieldEmail = driver.FindElement(By.Id("email"));
            var fieldPhone = driver.FindElement(By.Id("phone"));
            var fieldComments = driver.FindElement(By.Id("comments"));

            var buttonCreate = driver.FindElement(By.Id("create"));

            var firstNameData = " ";
            var lastNameData = "LastName" + DateTime.Now.Ticks;
            var emailData = "email@abv" + DateTime.Now.Ticks + ".bg";
            var phoneData = "+123456789" + DateTime.Now.Ticks;
            var commentsData = "comment goes here" + DateTime.Now.Ticks;

            //Act
            fieldFirstName.SendKeys(firstNameData);
            fieldLastName.SendKeys(lastNameData);
            fieldEmail.SendKeys(emailData);
            fieldPhone.SendKeys(phoneData);
            fieldComments.SendKeys(commentsData);
            buttonCreate.Click();

            var errorMessage = driver.FindElement(By.CssSelector("body > main > div"));

            //Assert
            Assert.AreEqual("Error: First name cannot be empty!", errorMessage.Text);

        }

        [OneTimeTearDown]
        public void TearDown()
        {
            driver.Quit();
        }
    }
}