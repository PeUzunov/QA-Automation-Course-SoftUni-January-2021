using NUnit.Framework;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Android;
using System;

namespace ContactBookMobileAppiumTests
{
    public class ContactBookMobileAppiumTests
    {
        private AndroidDriver<AndroidElement> driver;

        [OneTimeSetUp]
        public void SetupRemoteServer()
        {
            var appiumOptions = new AppiumOptions() { PlatformName = "Android" };
            appiumOptions.AddAdditionalCapability("app", @"C:\QA-Automation\12.Exam\contactbook-androidclient.apk");

            driver = new AndroidDriver<AndroidElement>(new Uri("http://[::1]:4723/wd/hub"), appiumOptions);

            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(60);
        }

        [Test]
        public void Test_SearchByKeyword_steve()
        {
            //Arrange
            var addressAPI = "https://contactbook.petaruzunov.repl.co/api";
            var keyword = "steve";

            //Act

            //Connect to the API
            var fieldContactBookAPI = driver.FindElementById("contactbook.androidclient:id/editTextApiUrl");
            fieldContactBookAPI.Clear();
            fieldContactBookAPI.SendKeys(addressAPI);
            var buttonConnect = driver.FindElementById("contactbook.androidclient:id/buttonConnect");
            buttonConnect.Click();

            //Search for keyword "steve"
            var fieldSearchByKeyword = driver.FindElementById("contactbook.androidclient:id/editTextKeyword");
            fieldSearchByKeyword.Clear();
            fieldSearchByKeyword.SendKeys(keyword);
            var buttonSearch = driver.FindElementById("contactbook.androidclient:id/buttonSearch");
            buttonSearch.Click();

            //Take data from results
            var resultContactIDs = driver.FindElementsById("contactbook.androidclient:id/textViewContactId"); 
            var resultsFirstName = driver.FindElementsById("contactbook.androidclient:id/textViewFirstName");
            var resultsLastName = driver.FindElementsById("contactbook.androidclient:id/textViewLastName");

            var resultFirstName = driver.FindElementById("contactbook.androidclient:id/textViewFirstName");
            var resultLastName = driver.FindElementById("contactbook.androidclient:id/textViewLastName");

            //Assert
            foreach (var resultContactID in resultContactIDs)
            {
                if (resultContactID.Text == "1")
                {
                    Assert.AreEqual("Steve Jobs", resultsFirstName[0].Text + " " + resultsLastName[0].Text);
                    break;
                }
            }

            //Or Assert like this
            Assert.AreEqual("Steve Jobs", resultFirstName.Text + " " + resultLastName.Text);
        }

        [OneTimeTearDown]
        public void TearDown()
        {
            driver.Quit();
        }
    }
}